package com.devskiller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Exercise {

    public List<Integer> findDuplicates(List<Integer> integers, int numberOfDuplicates) {
    	
    	
    	Map<Integer,Integer> hmap = new HashMap<Integer,Integer>();
    	  ArrayList<Integer> list=new ArrayList<Integer>();//Creating arraylist  

    
				
		for(Integer c:integers) {
			System.out.println(c);
			if(c!=null) {
			if(hmap.containsKey(c)) {
				hmap.put(c, hmap.get(c)+1);
				
			}
			else {
				hmap.put(c,1);
			}
			}
		}
		
		int length = 0;
		
		for(Entry<Integer, Integer> map:hmap.entrySet()) {
			//System.out.println(map.getKey() + "===" +map.getValue());
			
			if(map.getValue()==2) {
				list.add(map.getKey());
				System.out.println(map.getKey());
			}
		}
		
		return list;
		
    	
    }

}
